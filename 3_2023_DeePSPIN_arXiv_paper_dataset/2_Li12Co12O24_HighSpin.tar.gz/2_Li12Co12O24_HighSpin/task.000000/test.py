#!/bin/env python3

from analyzer.Spin import generate, test


#test()

#generate("./", ["Co", "Li", "O"])

import numpy as np

from dpdata import LabeledSystem

test = LabeledSystem("OUTCAR", "vasp/outcar", ["Co", "Li", "O"])


print(test["coords"][0][0])
print(test["forces"][0][0])

